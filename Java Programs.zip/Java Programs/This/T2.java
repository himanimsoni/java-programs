class T
{
	int a;
	void s()
	{
		int a=10;
		System.out.println(a);
		System.out.println(this.a);
	}
}

class T2
{
	public static void main(String args[])
	{
		T t=new T();
		t.a=100;
		t.s();
		T t1=new T();
		t1.a=200;
		t1.s();
	}
}