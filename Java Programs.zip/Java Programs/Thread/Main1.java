class Abc extends Thread
{
	int x1;
	Abc(int x)
	{
		x1=x;
		start();
	}

	public void run()
	{
		try
		{
		for(int i=1;i<=10;i++)
		{
			System.out.println(getName()+"="+i);
			Thread.sleep(x1);//500
		}
		}

		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

class Main1
{
	public static void main(String args[])
	{
		try
		{
		Abc a1=new Abc(1000);
		a1.setName("Thread 1");
		Abc a2=new Abc(500);
		a2.setName("Thread 2");
		//Abc a3=new Abc();
		//a3.setName("Thread 3");
		}
	catch(Exception e)
		{
			System.out.println(e);
		}
	}
}