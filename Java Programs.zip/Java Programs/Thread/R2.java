class R implements Runnable
{
		Thread t=new Thread(this);
		R()
		{
			t.start();
		}
	
		public void run()
		{
		try
		{
			for(int i=1;i<=5;i++)
			{
				System.out.println("T= "+i);
				Thread.sleep(1000);
			}
		}

		catch(Exception e)
		{
			System.out.println(e);
		}
		}
}

class R2
{
	public static void main(String args[])
	{
		R r1=new R();
		R r2=new R();
		R r3=new R();
	}
}