class T extends Thread
{
	
	public void run()
	{

		int i;
		try
		{
		for(i=0;i<=5;i++)
		{
			System.out.println("T= "+i);
			Thread.sleep(1000);
		}
		}
	

	catch(Exception e)
	{
		System.out.println(e);
	}
	}
}

class T2
{
	public static void main(String args[])
	{
		T t1=new T();
		t1.start();

		int j;
		try
		{
		for(j=0;j<=5;j++)
		{
			System.out.println("T2= "+j);
			Thread.sleep(500);
		}

		t1.join();
		
		System.out.println("Finish");
		
		}
	

	catch(Exception e)
	{
		System.out.println(e);
	}
	}
}