class R3 implements Runnable
{
	Thread t=new Thread(this);
	R3()
	{
		t.start();
	}

	public void run()
	{
		try
		{
		for(int i=1;i<=10;i++)
		{
			System.out.println(getName()+"="+i);
			Thread.sleep(500);
		}
		}

		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

class R4
{
	public static void main(String args[])
	{
		R3 r1=new R();
		r1.setName("Thread 1");
		R3 r2=new R3();
		r2.setName("Thread 2");
		R3 r4=new R3();
		r4.setName("Thread 3");
	}
}