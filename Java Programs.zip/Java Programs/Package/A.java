package P;
public class A
{
	public void s()
	{
		System.out.println("Hello");
	}
}

class B extends A
{
	void s1()
	{
		System.out.println("How r u?");
	}
}

class C
{
	public static void main(String args[])
	{
		B b1=new B();
		b1.s();
		b1.s1();
	}
}