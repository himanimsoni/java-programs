class A
{
	public static void main(String args[])
	{
	try
	{
		int a=1/1;
		System.out.println(a);
	}

	catch(Exception e)
	{
		System.out.println(e);
	}

	finally
	{
		System.out.println("End of Program");
	}
	}
}
