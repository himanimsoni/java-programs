class A4
{
	public static void main(String args[])
	{
	try
	{
		int a=1/1;

		try
		{
			int b=Integer.parseInt("123");
		}
		catch(NumberFormatException e)
		{
			System.out.println("Give integer input");
		}
		System.out.println(args[2]);

		catch(ArithmeticException e)
		{
			System.out.println("Divided by zero");
		}
	
	}
	}
}