import java.io.*;
class E3
{
	public static void main(String args[])
	{
		try
		{
			File f=new File("s.text");
			f.createNewFile();
		}
		catch
		(Exception e)
		{
			System.out.println(e);
		}
	}
}