class Abc
{
	void s()
	{
	try
	{
		System.out.println("S");
		s1();
		System.out.println("After S");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}

	void s1()
	{
	try
	{
		System.out.println("S1");
		s2();
		System.out.println("After S1");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}

	void s2()
	{
	try
	{
		int i=1/0;
		System.out.println(i);
	}
	catch(Exception e)
	{
		System.out.println(e);
		throw e;
	}
	}
}

class Main1
{
	public static void main(String args[])
	{
		Abc a1=new Abc();
		a1.s();
	}
}