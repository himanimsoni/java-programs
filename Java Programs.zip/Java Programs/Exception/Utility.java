class Ran
{
	public static void main(String args[])
	{
		int a=Integer.parseInt("123");
		System.out.println(a);

		Ran r=new Ran();
		
		int b = nextInt();
		System.out.println(b);
	}
}