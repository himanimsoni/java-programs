import java.util.*;
class Hemil extends Exception{}
class Vaishali extends Exception{}

class Custom
{
	void s()
	{
		try
		{
			System.out.println("Hii");
			s1();
			System.out.println("Bye");
		}
		catch(Exception e)
		{
			System.out.println("Error="+e);
		}
	}
	
	void s1() throws Hemil , Vaishali
	{
		Random r1=new Random();

		int a=r1.nextInt(15);
		System.out.println(a);

		if(a%2==0)
		{
			System.out.println("The number is even");
			Hemil h=new Hemil();
			throw h;
		}
		else
		{
			System.out.println("The number is odd");
			Vaishali v=new Vaishali();
			throw v;
		}
	}
}

class Custom1
{
	public static void main(String args[])
	{
		Custom c1=new Custom();
		c1.s();
	}
}