class E
{
	public static void main(String args[])
	{
		int a=1/1;
		System.out.println(a);

		String s="a";
		int i=s;
		int b=Integer.parseInt(s);
		System.out.println(b);
	}
}