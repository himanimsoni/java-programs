import java.util.*;
class Ran
{
	public static void main(String args[])
	{
		Random r1=new Random();

		int a=r1.nextInt(15);
		System.out.println(a);

		if(a/2==0)
		{
			System.out.println("The number is even");
		}
		else
		{
			System.out.println("The number is odd");
		}
	}
}