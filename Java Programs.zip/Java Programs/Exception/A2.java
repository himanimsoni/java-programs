class A2
{
	public static void main(String args[]) throws
	Exception
	{
		int a=1/1;
		System.out.println(a);
	}
}