class E1
{
	public static void main(String a[])
	{
		System.out.println(a[5]);
	}
}