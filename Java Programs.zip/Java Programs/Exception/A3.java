class A3
{
	public static void main(String args[])
	{
	try
	{
		int a=1/1;
		int b=Integer.parseInt("123");
		System.out.println(args[2]);
	}
	catch(ArithmeticException e)
	{
		System.out.println("Divided by zero");
	}
	catch(NumberFormatException e)
	{
		System.out.println("Give integer input");
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println("Wrong index number");
	}
	}
}