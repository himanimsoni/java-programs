class T
{
	public static void main(String a[])
	{
		try
		{
		System.out.println(a[0]);
		System.out.println(a[1]);
		
		if((a[0].contentEquals("Admin")) && (a[1].contentEquals("Amiraj")))
		{
			System.out.println("Logged in");
		}
		else
		{
	
			System.out.println("Login fail");
			throw new Exception("Vaishali");
		}
		}
		catch(Exception e)
		{
			System.out.println("Error="+e);
		}	
	}
}