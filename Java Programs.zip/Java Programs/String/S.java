class S
{
	public static void main(String args[])
	{
		String s=new String();
		s="Hello";

		char a=s.charAt(1);
		System.out.println(a);

		String b=s.concat(" Welcome");
		System.out.println(b);	

		int c=s.compareTo("Hello");
		System.out.println(c);

		boolean d=s.equals("Hello");
		System.out.println(d);

		int e=s.indexOf('o');
		System.out.println(e);

		String f=s.replace('l','b');
		System.out.println(f);

		int g=s.length();
		System.out.println(g);

		String h=s.substring(1,3);
		System.out.println(h);

		String i=s.toLowerCase();
		System.out.println(i);

		String j=s.toUpperCase();
		System.out.println(j);

		String k=s.trim();
		System.out.println(k);
	}
}