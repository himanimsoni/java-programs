interface A
{
	int a=10;
	void s();
	void s1();
}

interface B
{
	int a=20;
	void s2();
}

interface C extends A , B
{
	int a=30;
 	void s3();
}



class Abc implements C
{
	void x()
	{
		System.out.println("Hello");
	}
	void y()
	{
		System.out.println("Welcome");
	}
	public void s()
	{
		System.out.println(a);
	}
	public void s1()
	{
		System.out.println(a);
	}
	public void s2()
	{
		System.out.println(a);
	}
	public void s3()
	{
		System.out.println(a);
	}
}

class Main
{
	public static void main(String args[])
	{
		Abc a1=new Abc();
		a1.x();
		a1.y();
		a1.s();
		a1.s1();
		a1.s2();
		a1.s3();
	}
}