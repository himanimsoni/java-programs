interface Abc
{
	int a=10;
	public void s();
	public void s1();
}

interface Def
{
	int d=30;
	void s2();
}

class Xyz implements Abc , Def
{
	void x()
	{
		int b=20;
		System.out.println(b);
	}
	void y()
	{
		int c=30;
		System.out.println(c);
	}
	public void s()
	{
		System.out.println(a);
	}
	public void s1()
	{
		System.out.println(a);
	}
	public void s2()
	{
		System.out.println(d);
	}
}

class Mno
{
	public static void main(String args[])
	{
		Xyz x1=new Xyz();
		x1.x();
		x1.y();
		x1.s();
		x1.s1();
		x1.s2();
	}
}