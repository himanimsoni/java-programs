class SB
{
	public static void main(String args[])
	{
		StringBuffer s=new StringBuffer("Welcome To India");
		
		s.append(7);
		System.out.println(s);

		s.delete(2,4);
		System.out.println(s);

		s.deleteCharAt(7);
		System.out.println(s);

		s.insert(2,'r');
		System.out.println(s);

		s.reverse();
		System.out.println(s);

		s.append(7);
		System.out.println(s);
	}
}