class Maths
{
	public static void main(String args[])
	{
		int b=Math.abs(-10);
		System.out.println(b);

		float c=Math.abs(-7.000f);
		System.out.println(c);

		double d=Math.cos(0);
		System.out.println(d);

		double e=Math.exp(7.000002);
		System.out.println(e);

		double f=Math.floor(3.0002);
		System.out.println(f);

		double g=Math.ceil(2.0002);
		System.out.println(g);

		double h=Math.log(1);
		System.out.println(h);
		
		int i=Math.max(10,20);
		System.out.println(i);

		int j=Math.min(1,2);
		System.out.println(j);

		double k=Math.pow(2.0,2.0);
		System.out.println(k);

		double l=Math.sqrt(4.0);
		System.out.println(l);

		double m=Math.tan(90);
		System.out.println(m);

		double n=Math.round(2.26);
		System.out.println(n);
	}
}