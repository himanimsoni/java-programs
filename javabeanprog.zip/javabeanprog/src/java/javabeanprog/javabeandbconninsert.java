
package javabeanprog;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class javabeandbconninsert {
    
    Connection con=null;
    Statement stat=null;

   
    public javabeandbconninsert()
    {  
        try
        {    
       
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdatabase","root","root");
                 
        }catch(Exception e ){System.out.println("error occured in connection" +e);}    
        
        
    }
    public int Roll_no;

    public int getRoll_no() {
        return Roll_no;
    }

    public void setRoll_no(int Roll_no) {
        this.Roll_no = Roll_no;
    }

        public String Sname;

    public String getSname() {
        return Sname;
    }

    public void setSname(String Sname) {
        this.Sname = Sname;
    }
    
  

    public int insert() throws Exception
    {
        
           PreparedStatement ps= con.prepareStatement("INSERT my_table(Roll_no,Sname) VALUES(?,?)");
           ps.setInt(1, Roll_no);
           ps.setString(2, Sname);
           
           int a = ps.executeUpdate();
           
           if(a==1)
           {
               return a;
           }else
           {
               return a;
           }

    }
   
}
