
package client_ack;

import java.io.*;
import java.net.*;

public class Client_ack {

    
    public static void main(String[] args)throws Exception {
        
        try{
            
            String Str;
            String Str1;
            BufferedReader input_user = new BufferedReader(new InputStreamReader(System.in));
            Socket s1 = new Socket("app",1235);
            DataOutputStream out_server= new DataOutputStream(s1.getOutputStream());
            BufferedReader in_server = new BufferedReader(new InputStreamReader(s1.getInputStream()));
            System.out.println("enter your string");
            Str=input_user.readLine();
            out_server.writeBytes(Str+ "\n");
            Str1 = in_server.readLine();
            System.out.println("From server" +Str1);
            s1.close();
        
        }catch(Exception ex){}
            
        // TODO code application logic here
        }
    } 

