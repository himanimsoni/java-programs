
package clientserver_tocap;

import java.io.*;
import java.net.*;

public class server_tocap {
        public static void main(String args[])throws Exception
    {    
            try
            {
                DatagramSocket sd= new DatagramSocket(1245);
                InetAddress ip_add = InetAddress.getByName("localhost");
                
               
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                byte in_bo[]= new byte[1024];
                byte out_bo[]=new byte[1024];
             
              while(true)  
              {    
                //reciving from client
                DatagramPacket p3 = new DatagramPacket(in_bo,in_bo.length);
                sd.receive(p3);
                String str = new String(p3.getData());
                System.out.println("Client: " +str);
                 if ( str.equalsIgnoreCase("BYE") )
 	           break;
                
                //sending to client 
                InetAddress ip_add1=p3.getAddress();
                int port = p3.getPort();
                
                String str1=str.toUpperCase();
                out_bo=str1.getBytes();
                DatagramPacket p4 = new DatagramPacket(out_bo,out_bo.length,ip_add1,port);
                sd.send(p4);
                
                   if ( str1.equalsIgnoreCase("BYE") )
 	           break;
              }  
                
              sd.close();
              br.close();
                
            }catch(Exception e){System.out.println("error occured " +e);}
    }
    
}
