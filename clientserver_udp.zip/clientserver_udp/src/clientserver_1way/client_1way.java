
package clientserver_1way;

import java.io.*;
import java.net.*;

public class client_1way {
    public static void main(String args[])throws Exception
    {
        try{
            DatagramSocket sd = new DatagramSocket();
            InetAddress add = InetAddress.getByName("localhost");
           
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            byte bo[]=new byte[1024];
            String s;
            System.out.println("Enter your message to server: ");
            s=br.readLine();
            bo=s.getBytes();
            
            DatagramPacket dp1 = new DatagramPacket(bo,bo.length,add,1234);
            sd.send(dp1);
            
            sd.close();
            
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
}
