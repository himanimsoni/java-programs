
package clientserver_1way;

import java.io.*;
import java.net.*;


public class server_1way {
    public static void main(String args[])throws Exception
    {
        try{
            DatagramSocket sc = new DatagramSocket(1234);
           
            byte bs[]=new byte[1024];
            
                while(true)
                {   
                    DatagramPacket dp2 = new DatagramPacket(bs,bs.length);
                    sc.receive(dp2);

                    String s=new String(dp2.getData());
                    System.out.println("Client: " +s);
                } 
            
           
            
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
    
}
