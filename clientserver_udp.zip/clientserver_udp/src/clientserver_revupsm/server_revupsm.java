
package clientserver_revupsm;

import java.io.*;
import java.net.*;

public class server_revupsm {
        public static void main(String args[])throws Exception
    {    

            try
            {
                DatagramSocket sd= new DatagramSocket(1233);
                InetAddress ip_add = InetAddress.getByName("localhost");
                
               
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                byte in_bo[]= new byte[5];
                byte out_bo[]=new byte[5];
                String newstr="";
                String revstr="";
                char ch1,ch2=' ';
             
              while(true)  
              {    
                //reciving from client
                DatagramPacket p3 = new DatagramPacket(in_bo,in_bo.length);
                sd.receive(p3);
                String str=new String(p3.getData());
                System.out.println("Client: " +str);
                
                
                //sending to client 
                InetAddress ip_add1=p3.getAddress();
                int port = p3.getPort();
                System.out.println("entering for");
                
                for(int i=0;i<str.length();i++)
                {
                   ch1=str.charAt(i);
                   if(ch1>='A'&&ch1<='Z')
                     ch2=Character.toLowerCase(ch1);
                   if(ch1>='a'&&ch1<='z')
                     ch2=Character.toUpperCase(ch1);
                   if(ch1==' ')
                   ch2=' ';
                   
                  newstr = newstr+ch2;
                }
                
                System.out.println(newstr);
                System.out.println("exiting for");
                for(int j=newstr.length()-1;j>=0;j--)
                {   
                    revstr= revstr+newstr.charAt(j);
                }
                revstr=revstr+'\n';
                System.out.println(revstr);
                System.out.println("entering reverse");

                out_bo=revstr.getBytes();
                DatagramPacket p4 = new DatagramPacket(out_bo,out_bo.length,ip_add1,port);
                sd.send(p4);
                
                   if ( str.equalsIgnoreCase("BYE") )
 	           break;
              }  
                
              sd.close();
              br.close();
                
            }catch(Exception e){System.out.println("error occured " +e);}
    }
    
}
