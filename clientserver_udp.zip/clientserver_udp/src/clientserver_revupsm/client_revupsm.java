
package clientserver_revupsm;

import java.io.*;
import java.net.*;

public class client_revupsm {
    public static void main(String arhs[])throws Exception 
    {
        try{
             DatagramSocket sd = new DatagramSocket();
             InetAddress add = InetAddress.getByName("localhost");
             
             BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
             byte b_in[] = new byte[5];
             byte b_out[] = new byte[5];
             
             String s;
             
             while(true)
             {    
             //Sending data to server 
             System.out.println("Enter your message to server: ");
             s=br.readLine();
             b_out=s.getBytes();
             DatagramPacket p1 = new DatagramPacket(b_out,b_out.length,add,1233);
             sd.send(p1);
              if ( s.equalsIgnoreCase("BYE") )
 	           break;
             
             //reciving from server
             DatagramPacket p2 = new DatagramPacket(b_in,b_in.length);
             sd.receive(p2);
             String rec_str=new String(p2.getData());
             System.out.println("Server: " +rec_str);
               if ( rec_str.equalsIgnoreCase("BYE") )
 	           break;
             
             } 
             
             sd.close();
             br.close();
        
        }catch(Exception e){System.out.println("error occured " +e);}
    }
    
}
