
package server_ack;

import java.io.*;
import java.net.*;
import java.lang.*;

public class Server_ack {

    public static void main(String[] args) {
        try{
               String str3;
               String str4;
               ServerSocket s2 = new ServerSocket(1235);
               
                   Socket s3 =s2.accept();
                   BufferedReader in_client = new BufferedReader(new InputStreamReader(s3.getInputStream()));
                   DataOutputStream out_client = new DataOutputStream(s3.getOutputStream());
                   str3=in_client.readLine();
                   str4 = str3+ "-> Received" +'\n';
                   out_client.writeBytes(str4);
               
            
        } catch(Exception ex){}
        // TODO code application logic here
    }
    
}
