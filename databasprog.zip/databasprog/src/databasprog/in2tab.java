
package databasprog;

import java.sql.*;

public class in2tab {
    public static void main(String args[])
    {
        try
        {
            Connection con=null;
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdatabase","root","root");
            System.out.println("Connection established");
            Statement stat=con.createStatement();
            int val=stat.executeUpdate("INSERT my_table VALUES("+ 13 + "," + "'Aman'" + ")");
            System.out.println("one row added");
            
            stat.close();
            con.close();
            
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
}
