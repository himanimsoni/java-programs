
package databasprog;

import java.sql.*;

public class updtab {
    public static void main(String args[])
    {
        try
        {
                Connection con=null;
                
                Class.forName("com.mysql.jdbc.Driver");
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdatabase","root","root");
                Statement stat=con.createStatement();
                
                String s="UPDATE my_table SET Sname='Himani' WHERE Roll_no=13";
                stat.executeUpdate(s);
                
                s="SELECT * FROM my_table";
                ResultSet rs=stat.executeQuery(s);
                
                System.out.println("Displaying contents of table");
                
                while(rs.next())
                {
                    int Roll_no = rs.getInt("Roll_no");
                    String Sname=rs.getString("Sname");
                    
                    System.out.println("Roll number:" +Roll_no);
                    System.out.println("Name:" +Sname);
                }
                rs.close();
                con.close();
                stat.close();
                
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
}
