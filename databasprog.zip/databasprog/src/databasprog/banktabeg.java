
package databasprog;

import java.sql.*;

public class banktabeg {
    public static void main(String args[])
    {
        try
        {
            Connection con=null;
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdatabase","root","root");
            System.out.println("connection successful");
            Statement stat=con.createStatement();
            
           /* int result = stat.executeUpdate("CREATE TABLE bank(Accno INT, Cname VARCHAR(20),Bal FLOAT(3), Phone VARCHAR(20), Add1 VARCHAR(20))");
            System.out.println("Table created"); */
            
           /* int val = stat.executeUpdate("INSERT bank VALUES("+ 1 +","+ "'Aman'" +","+ 1000 +","+ 12345 +","+ "'Bopal'" +")");
            int val1 = stat.executeUpdate("INSERT bank VALUES("+ 2 +","+ "'Ram'" +","+ 3000 +","+ 12334 +","+ "'Satellite'" +")");
            int val3 = stat.executeUpdate("INSERT bank VALUES("+ 3 +","+ "'Shyam'" +","+ 4500 +","+ 23345 +","+ "'Ambavadi'" +")"); 
            int val3 = stat.executeUpdate("INSERT bank VALUES("+ 4 +","+ "'Ganesh'" +","+ 21000 +","+ 44345 +","+ "'Gold Coin'" +")");
            System.out.println("rows added"); */
            
           /* String s="UPDATE bank SET Cname='Himani' WHERE Accno=4";
            stat.executeUpdate(s);
            System.out.println("Updated Successfully"); */
            
           /* int result = stat.executeUpdate("DELETE FROM bank WHERE Accno=1");
            System.out.println("Deleted row successfully"); */
            
            String s = "SELECT * FROM bank WHERE Bal>20000";
            ResultSet rs =stat.executeQuery(s);
            System.out.println("Displaying table contents...");
            
            while(rs.next())
            {
                int Accno = rs.getInt("Accno");
                String Cname = rs.getString("Cname");
                float Bal = rs.getFloat("Bal");
                String Phone = rs.getString("Phone");
                String Add1 = rs.getString("Add1");
                
                System.out.println("Account Number: " +Accno);
                System.out.println("Name: " +Cname);
                System.out.println("Balance: " +Bal);
                System.out.println("Phone Number: " +Phone);
                System.out.println("Address: " +Add1);
            }
            
            con.close();
            stat.close();
            rs.close();
            
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
}
