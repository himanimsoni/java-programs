
package databasprog;

import java.sql.*;

public class disptab {
    public static void main(String args[])
    {
        try{
            
            Connection con=null;
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdatabase","root","root");
            Statement stat=con.createStatement();
            String s="SELECT * FROM my_table";
            ResultSet rs=stat.executeQuery(s);
            System.out.println("Displaying contents of table");
            
            while(rs.next())
            {
               int Roll_no = rs.getInt("Roll_no");
               String Name = rs.getString("Sname");
               
               //displaying values 
               System.out.println("Roll Number:" +Roll_no);
               System.out.println("Student Name:" +Name);
         
            }
            rs.close();
            con.close();
            stat.close();
            
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
}
