
package databasprog;

import java.sql.*;

public class calstaeg {
     public static void main(String args[])
    {
         try
        {
            Connection con=null;
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdatabase","root","root");
            System.out.println("connection successful");
            Statement stat=con.createStatement();
            
           
            
            CallableStatement cs = con.prepareCall("CALL listnames()");
          
            ResultSet rs=cs.executeQuery();
            
            while(rs.next())
            {
                int Roll_no = rs.getInt(1);
                String Sname = rs.getString(2);
                
                System.out.println("Roll Number: " +Roll_no);
                System.out.println("Name: " +Sname);
            } 
            
            con.close();
            stat.close();
            rs.close();
           
            
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
    
}
