
package databasprog;

import java.sql.*;

public class prestaeg {
    public static void main(String args[])
    {
         try
        {
            Connection con=null;
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdatabase","root","root");
            System.out.println("connection successful");
            Statement stat=con.createStatement();
            
            /* int result = stat.executeUpdate("CREATE TABLE library(Accno INT, Bname VARCHAR(20))");
            System.out.println("Table created"); */
            
            PreparedStatement ps = con.prepareStatement("INSERT library VALUES(?,?)");
           /* ps.setInt(1,2);
            ps.setString(2,"WT");*/  //if more statements like this are added then more rows are added too
            ps.setInt(1,1);
            ps.setString(2,"AJT");    
            ps.executeUpdate();
            System.out.println("rows added");
            
            String s="SELECT * FROM library";
            ResultSet rs=stat.executeQuery(s);
            
            while(rs.next())
            {
                int Accno = rs.getInt("Accno");
                String Bname = rs.getString("Bname");
                
                System.out.println("Account number of book: " +Accno);
                System.out.println("Title: " +Bname);
            }
            
            con.close();
            stat.close();
            rs.close();
           
            
        }catch(Exception e){System.out.println("error occured" +e);}
    }
    
}
